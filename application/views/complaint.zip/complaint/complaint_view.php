<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="container-fluid">	
	<div class="page_heading">
		<h1 style="float: left;">View Complaint</h1> <?php echo $this->breadcrumbs->show(); ?>			
	</div>
	
	<style>

</style>
	
	<div class="row">
		<div class="col-sm-3 conpalintInfoleft" style=''>	
			<div class="page_heading">
				<h5>Complaint Information</h5>
			</div>
			<div class="conpalintInfo">
				<div class="row cininfotext">
					<div class="col-sm-12">
						<label class='float-left'>Username:</label>
					</div>
					<div class="col-sm-12">
						<label class='float-left'><b><?php echo $compaint->username; ?></b></label>
					</div>
				</div>
			
			
				<div class="row cininfotext">
					<div class="col-sm-12" style='border:0px solid red;'>
						<label class='float-left'>Company Name:</label>
					</div>
					<div class="col-sm-12" style='border:0px solid red;'>
						<label class='float-left'><b><?php echo $compaint->company_name; ?></b></label>
					</div>
				</div>
			
				<div class="row cininfotext">
					<div class="col-sm-12" style='border:0px solid red;'>
						<label class='float-left'>Category of Complaint:</label>
					</div>
					<div class="col-sm-12" style='border:0px solid red;'>
						<label class='float-left'><b><?php echo $compaint->complaint_category_name; ?></b></label>
					</div>
				</div>
			
				<div class="row cininfotext">
					<div class="col-sm-12" style='border:0px solid red;'>
						<label class='float-left'>Sub-Category of Complaint:</label>
					</div>
					<div class="col-sm-12" style='border:0px solid red;'>
						<label class='float-left'><b><?php echo $compaint->product_category; ?></b></label>
					</div>
				</div>
			
				<div class="row cininfotext">
					<div class="col-sm-12" style='border:0px solid red;'>
						<label class='float-left'>Mode of Complaint:</label>
					</div>
					<div class="col-sm-12" style='border:0px solid red;'>
						<label class='float-left'><b><?php echo $compaint->complaint_mode_name; ?></b></label>
					</div>
				</div>
			
				<div class="row cininfotext">
					<div class="col-sm-12" style='border:0px solid red;'>
						<label class='float-left'>Concern Department for Action:</label>
					</div>
					<div class="col-sm-12" style='border:0px solid red;'>
						<label class='float-left'><b><?php echo $compaint->concern_dept_name; ?></b></label>
					</div>
				</div>
			
			
				<div class="row cininfotext">
					<div class="col-sm-12" style='border:0px solid red;'>
						<label class='float-left'>Date of Customer Intimation:</label>
					</div>
					<div class="col-sm-12" style='border:0px solid red;'>
						<label class='float-left'><b><?php echo date('d-m-Y',strtotime($compaint->date_of_customer_info)); ?></b></label>
					</div>
				</div>
			
				<div class="row cininfotext">
					<div class="col-sm-12" style='border:0px solid red;'>
						<label class='float-left'>Date of Complaint:</label>
					</div>
					<div class="col-sm-12" style='border:0px solid red;'>
						<label class='float-left'><b><?php echo date('d-m-Y',strtotime($compaint->date_added)); ?></b></label>
					</div>
				</div>
			</div>
		</div>
			<script src="<?php echo base_url(); ?>assets/script.js"></script>
			<div class="col-sm-9 conpalintInforight" >
				<div class="Complaintdetals">
					<div class="page_heading">
						<h5 class="text-left">Details of Complaint</h5>
					</div>
					<div class="messaging">
					  <div class="inbox_msg">	
						<div class="mesgs">
						  <div class="msg_history">
							<?php if($compaintDetails){ $i=1;  $count = count($compaintDetails); ?>
								<?php foreach($compaintDetails as $compaintDetail){ ?>				
									
										<div class="received_withd_msg <?php if($i > 1){ echo "receive_complaint"; } ?>">
											<?php
											$dateTimeDetail = new DateTime($compaintDetail['date_added']);
											$dateTimeDetail->format();
											?>	
										  <div class="title"><h6>Admin <span class="dat_time"><?php echo $dateTimeDetail->format('h:i a'); ?>    |    <?php echo $dateTimeDetail->format('d F Y'); ?></span></h6>  </div>
														  
										  <span class="message_text"><?php echo nl2br($compaintDetail['message']); ?></span>
										  <?php if($i==1 && $count > 1){ ?>
											<span class="readmore"><a id="complaintredas" >Read all Complaint...</a></span>
										  <?php } ?> 
										  
										  <?php if($i==$count && $count > 1){ ?>
											<span class="readmore"><a id="complainthide" >Hide Complaint...</a></span>
										  <?php } ?>
										</div>
											
								<?php $i++; } ?>
							<?php } ?>
							
						  </div>
						  <div class="type_msg">
							<div class="input_msg_write">
							  <div class="row">
									<form method="post" id="complaintDetailForm" style="width:100%;">
										<div class="col-sm-12">
										   <div class="form-group">
											<textarea name="complaint"  class="form-control text-capitalize complaint" rows="2" required></textarea>
											<input type="hidden" name="mess_type" value="complaint">
											<input type="hidden" name="complaint_id" value="<?php echo $compaint->complaint_id; ?>">
										  </div>
											<div class="row">
												<div class="col-sm-3"> </div><div class="col-sm-9"> <button type="button" id="complaintBtn" class="btn btn-primary float-right"> Save</button> </div>
											</div>				
										</div>
									</form>
								</div>
							</div>
						  </div>
						</div>
					  </div>
					</div>
				</div>
				
				<div class="Correctivedetals">
					<div class="page_heading">
						<h5 class="text-left">Brief of Corrective Action Taken</h5>
					</div>
					<div class="messaging">
					  <div class="inbox_msg">	
						<div class="mesgs">
						  <div class="msg_history">
							<?php if($compaintCorrectives){  $j=1;  $count = count($compaintCorrectives); ?>
								<?php foreach($compaintCorrectives as $compaintCorrective){ ?>				
									
										<div class="received_withd_msg <?php if($j > 1){ echo "receive_Corrective"; } ?>">
											<?php
											$dateTimeDetail = new DateTime($compaintCorrective['date_added']);
											$dateTimeDetail->format();
											?>	
										  <div class="title"><h6>Admin <span class="dat_time"><?php echo $dateTimeDetail->format('h:i a'); ?>    |    <?php echo $dateTimeDetail->format('d F Y'); ?></span></h6>  </div>
														  
										  <span class="message_text"><?php echo nl2br($compaintCorrective['message']); ?></span>									  
										  
										  <?php if($j==1 && $count > 1){ ?>
											<span class="readmore"><a id="correctiveredas" >Read all Complaint...</a></span>
										  <?php } ?> 
										  
										  <?php if($j==$count && $count > 1){ ?>
											<span class="readmore"><a id="correctivehide" >Hide Complaint...</a></span>
										  <?php } ?>
										</div>
											
								<?php $j++; } ?>
							<?php } ?>
						  </div>
						  <div class="type_msg">
							<div class="input_msg_write">
								<div class="row">
									<form method="post" id="correctiveForm" style="width:100%;">
										<div class="col-sm-12">
										   <div class="form-group">
											<textarea name="complaint"  class="form-control text-capitalize complaint" rows="2" required></textarea>
											<input type="hidden" name="mess_type" value="corrective">
											<input type="hidden" name="complaint_id" value="<?php echo $compaint->complaint_id; ?>">
										  </div>
											<div class="row">
												<div class="col-sm-3"> <!-- <input type="file" name="complaint_file" required> --> </div><div class="col-sm-9"> <button type="button" id="correctiveFormBtn" class="btn btn-primary float-right"> Save</button> </div>
											</div>				
										</div>
									</form>
								</div>
							</div>
						  </div>
						</div>
					  </div>
					</div>
				</div>
				
				<div class="Preventivedetals">
					<div class="page_heading">
						<h5 class="text-left">Brief of Preventive Action Taken</h5>
					</div>
					<div class="messaging">
					  <div class="inbox_msg">	
						<div class="mesgs">
						  <div class="msg_history">
							<?php if($compaintPreventives){ $k=1;  $count = count($compaintPreventives); ?>
								<?php foreach($compaintPreventives as $compaintPreventive){ ?>				
									
										<div class="received_withd_msg <?php if($k > 1){ echo "receive_preventive"; } ?>">
											<?php
											$dateTimeDetail = new DateTime($compaintPreventive['date_added']);
											$dateTimeDetail->format();
											?>	
										  <div class="title"><h6>Admin <span class="dat_time"><?php echo $dateTimeDetail->format('h:i a'); ?>    |    <?php echo $dateTimeDetail->format('d F Y'); ?></span></h6>  </div>
														  
										  <span class="message_text"><?php echo nl2br($compaintPreventive['message']); ?></span>
										  
										   <?php if($k==1 && $count > 1){ ?>
											<span class="readmore"><a id="preventiveredas" >Read all Complaint...</a></span>
										  <?php } ?> 
										  
										  <?php if($k==$count && $count > 1){ ?>
											<span class="readmore"><a id="preventivehide" >Hide Complaint...</a></span>
										  <?php } ?>
										</div>
											
								<?php $k++; } ?>
							<?php } ?>
						  </div>
						  <div class="type_msg">
							<div class="input_msg_write">
							  <div class="row">
									<form method="post" id="preventiveForm" style="width:100%;">
										<div class="col-sm-12">
										   <div class="form-group">
											<textarea name="complaint"  class="form-control text-capitalize complaint" rows="2" required></textarea>
											<input type="hidden" name="mess_type" value="preventive">
											<input type="hidden" name="complaint_id" value="<?php echo $compaint->complaint_id; ?>">
										  </div>
											<div class="row">
												<div class="col-sm-3"> <!-- <input type="file" name="complaint_file" required> --></div><div class="col-sm-9"> <button type="button" id="preventiveFormBtn" class="btn btn-primary float-right"> Save</button> </div>
											</div>				
										</div>
									</form>
								</div>
							</div>
						  </div>
						</div>
					  </div>
					</div>
				</div>
			</div>							
		</div>
	</div>




</div>
<script>	
	$(document).ready(function () {	
		//complaint
		$("#complaintBtn").click(function(){
			var vlue = $("#complaintDetailForm .complaint").val();
			if(vlue == ''){
				alert("Please enter message");
				return false;
			}
			var data_form = $('#complaintDetailForm').serialize();						
			$.ajax({
				url:'<?php echo site_url('addComplaintMessage');?>',
				method: 'post',
				data: data_form,
				dataType: 'json',
				success: function(response){
					location.reload();
				}
			});				
		});	

		//Corrective
		$("#correctiveFormBtn").click(function(){
			var vlue = $("#correctiveForm .complaint").val();
			if(vlue == ''){
				alert("Please enter message");
				return false;
			}
			var data_form = $('#correctiveForm').serialize();						
			$.ajax({
				url:'<?php echo site_url('addComplaintMessage');?>',
				method: 'post',
				data: data_form,
				dataType: 'json',
				success: function(response){
					location.reload();
				}
			});				
		});	
		
		//preventive
		$("#preventiveFormBtn").click(function(){
			var vlue = $("#preventiveForm .complaint").val();
			if(vlue == ''){
				alert("Please enter message");
				return false;
			}
			var data_form = $('#preventiveForm').serialize();						
			$.ajax({
				url:'<?php echo site_url('addComplaintMessage');?>',
				method: 'post',
				data: data_form,
				dataType: 'json',
				success: function(response){
					location.reload();
				}
			});				
		});	
		
		//complaint
		$('.receive_complaint').hide();		
		$('#complaintredas').on('click',function(){
			$(".receive_complaint").slideToggle( "slow" );
		  $('.receive_complaint').show();
		  $('#complaintredas').hide();
		  $('#complainthide').show();
		});
		
		$('#complainthide').on('click',function(){
			$(".receive_complaint").slideToggle( "slow" );
		  $('.receive_complaint').hide();
		  $('#complainthide').hide();
		  $('#complaintredas').show();
		});
		
		
		//Corrective
		$('.receive_Corrective').hide();		
		$('#correctiveredas').on('click',function(){
			$(".receive_Corrective").slideToggle( "slow" );
		  $('.receive_mess_hide').show();
		  $('#correctiveredas').hide();
		  $('#correctivehide').show();
		});
		
		$('#correctivehide').on('click',function(){
			$(".receive_Corrective").slideToggle( "slow" );
		  $('.receive_Corrective').hide();
		  $('#correctivehide').hide();
		  $('#correctiveredas').show();
		});
		
		
		//preventive
		$('.receive_preventive').hide();		
		$('#preventiveredas').on('click',function(){
			$(".receive_preventive").slideToggle( "slow" );
		  $('.receive_preventive').show();
		  $('#preventiveredas').hide();
		  $('#preventivehide').show();
		});
		
		$('#preventivehide').on('click',function(){
			$(".receive_preventive").slideToggle( "slow" );
		  $('.receive_preventive').hide();
		  $('#preventivehide').hide();
		  $('#preventiveredas').show();
		});
		
	});	
</script>