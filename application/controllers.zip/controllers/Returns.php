<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Returns extends CI_Controller {
	public function __construct() {
		
		parent::__construct();
		$this->load->library(array('session'));
		if(empty($this->session->userdata('user_id'))){
			redirect('/');
		}
		
			$this->load->library('permission');
		$this->permission->getNotPermission();
		
		$this->load->helper(array('url'));
		$this->load->model('returns_model');
		$this->load->model('challan_model');
		$this->load->model('order_model');
		$this->load->model('quotation_model');
		$this->load->model('customer_model');
		$this->load->model('product_model');
		$this->load->language('language_lang');	
		$this->load->library('breadcrumbs');
		$this->load->library('pagination');
	}
	
	public function index(){
		$this->breadcrumbs->push('Dashboard', '/dashboard');
		$this->breadcrumbs->push('Returns List', '/returns');
		
		$data['success'] = $this->session->success;		
		
		$data['form_action']= 'returns';
		$data['stores'] = $this->quotation_model->getStore();
		
		/* Pagination */
		$total_rows = $this->returns_model->getTotalChallanProduct($this->input->get());	
		$per_page =25;
		$config['base_url'] = site_url().'/returns';
		$config['per_page'] = $per_page;		
		$config['total_rows'] = $total_rows;		
		$this->pagination->initialize($config);
		$page = 1;			
		if(!empty($this->input->get('per_page'))){
			$page = $this->input->get('per_page');
		}		
		$start = ($page-1)*$per_page;		
		$pagination = $this->pagination->create_links();		
		if($pagination != "")
		{
			$num_pages = ceil($total_rows / $per_page);
			$data['pagination'] = '<p style="margin-top: 10px;">We have ' . $total_rows . ' records in ' . $num_pages . ' pages ' . $pagination . '</p>';
			
		}		
		/* Pagination */
		
		$data['challanProInfo'] = $this->returns_model->getChallanProduct($per_page, $start,$this->input->get());
		
		$this->load->view('common/header');
		$this->load->view('returns/returns_list', $data);
		$this->load->view('common/footer');	
		unset($_SESSION['success']);
	}	
	
	public function addReturns(){
		
		$this->breadcrumbs->push('Dashboard', '/dashboard');
		$this->breadcrumbs->push('Returns List', '/returns');
		$this->breadcrumbs->push('Add Returns', 'addReturns');
		
		$data['action'] = site_url().'/addReturns?challan_no='.$this->input->get('challan_no').'&invoice_no='.$this->input->get('invoice_no');
	
		if($this->input->get('challan_no') || $this->input->get('invoice_no')){
			if($this->input->get('challan_no')){
				$data['challan_no'] = $this->input->get('challan_no');
			} else {
				$data['challan_no'] = '';
			}
			
			if($this->input->get('invoice_no')){
				$data['invoice_no'] = $this->input->get('invoice_no');
			} else {
				$data['invoice_no'] = '';
			}
			
			if($this->input->get('id')){
				$data['challan_pro_id'] = $this->input->get('id');
			} else {
				$data['challan_pro_id'] = '';
			}
			
			$data['challanInfo'] = $this->returns_model->getChallanById($data['challan_no'],$data['invoice_no']);
			$data['orderInfo'] = $this->order_model->getOrderById($data['challanInfo']->order_id);			
			$data['challanProInfo'] = $this->returns_model->getChallanInfo($data['challan_no'],$data['invoice_no'],$data['challan_pro_id']);			
			
			$data['returnNotes'] = $this->returns_model->getReturnNote($data['challan_no']);
		}
		
		if ($this->input->server('REQUEST_METHOD') == 'POST'){
			
			if($this->input->post('invoice_reason') == ''){
				
				if($this->input->post('invoiceno') == ''){
				
					//$data['error'] = "Invoice details are not saved in dispatch Note/Challan";
					$data['error'] = "Please Enter Reason For no Invoice.";
					$this->load->view('common/header');
					$this->load->view('returns/returns_form', $data);
					$this->load->view('common/footer');									
					return false;
				
				}
				
			}
			
			foreach($this->input->post('sold_qty') as $index => $sold_qty){
					$qty_returns = $this->input->post('qty_returns');
					if($qty_returns[$index] > $sold_qty){
						$data['error'] = "Please Enter Sold Qty Or Less then";
						$this->load->view('common/header');
						$this->load->view('returns/returns_form', $data);
						$this->load->view('common/footer');									
						return false;
					}							
			}		
						
			$this->returns_model->addReturns($this->input->post());			
			$_SESSION['success']      = "Success: You have Returns Qty";
			redirect('/returns');
		}
		
		$this->load->view('common/header');
		$this->load->view('returns/returns_form', $data);
		$this->load->view('common/footer');					
	}
	
	public function returnsPrint(){
					
		if($this->input->get('challan_no') || $this->input->get('invoice_no')){
			if($this->input->get('challan_no')){
				$data['challan_no'] = $this->input->get('challan_no');
			} else {
				$data['challan_no'] = '';
			}
			
			if($this->input->get('invoice_no')){
				$data['invoice_no'] = $this->input->get('invoice_no');
			} else {
				$data['invoice_no'] = '';
			}
			
			if($this->input->get('id')){
				$data['challan_pro_id'] = $this->input->get('id');
			} else {
				$data['challan_pro_id'] = '';
			}
			
			$data['challanInfo'] = $this->returns_model->getChallanById($data['challan_no'],$data['invoice_no']);
			$data['orderInfo'] = $this->order_model->getOrderById($data['challanInfo']->order_id);	
			$data['customerInfo'] = $this->customer_model->getCustomerById($data['challanInfo']->customer_id);		
			
			$data['challanProInfo'] = $this->returns_model->getChallanInfo($data['challan_no'],$data['invoice_no'],$data['challan_pro_id']);			
			$data['returnNotes'] = $this->returns_model->getReturnNote($data['challan_no']);
		}
		
		$this->load->view('returns/returns_print', $data);
	}
		
}