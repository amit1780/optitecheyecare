<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<!-- <html lang="en">
<head>
    <meta charset="utf-8">
    <title>Site Under Maintenance</title>
</head>
<body>
    <h1>Site Under Maintenance</h1>
    <div>
        <div> 
            <p> Under-construction </p>
            <p>We are performing Maintenance on the server. Website will be right back with in an hour.</p>
        </div>
    </div>
</body>
</html> -->